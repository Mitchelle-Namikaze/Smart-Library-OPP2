from pydantic import BaseModel, ConfigDict
from typing import Optional


class BookCreate(BaseModel):
    title: str
    author: str
    genre: str


class BookUpdate(BaseModel):
    title: Optional[str] = None
    author: Optional[str] = None
    genre: Optional[str] = None
    available: Optional[bool] = None


class BookResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    title: str
    author: str
    genre: str
    available: bool