from pydantic import BaseModel, ConfigDict
from datetime import datetime


class BorrowCreate(BaseModel):
    user_id: int
    book_id: int


class BorrowResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    user_id: int
    book_id: int
    borrow_date: datetime
    due_date: datetime
    returned: bool