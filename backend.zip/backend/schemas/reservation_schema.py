from pydantic import BaseModel
from datetime import datetime


class ReservationCreate(BaseModel):
    user_id: int
    book_id: int


class ReservationResponse(BaseModel):
    id: int
    user_id: int
    book_id: int
    status: str
    request_date: datetime

    class Config:
        from_attributes = True