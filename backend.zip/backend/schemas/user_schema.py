from pydantic import BaseModel, ConfigDict
from typing import Optional


class UserCreate(BaseModel):
    full_name: str
    email: str
    password: str
    role: Optional[str] = "Student"


class UserResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    full_name: str
    email: str
    role: str