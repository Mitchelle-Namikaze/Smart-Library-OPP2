from sqlalchemy import Column, Integer, String, ForeignKey, DateTime
from datetime import datetime

from database import Base


class Reservation(Base):
    __tablename__ = "reservations"

    id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    user_id = Column(
        Integer,
        ForeignKey("users.id")
    )

    book_id = Column(
        Integer,
        ForeignKey("books.id")
    )

    status = Column(
        String,
        default="Pending"
    )

    request_date = Column(
        DateTime,
        default=datetime.utcnow
    )