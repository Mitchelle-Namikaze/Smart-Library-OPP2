from sqlalchemy import Column, Integer, ForeignKey, DateTime, Boolean
from datetime import datetime, timedelta

from database import Base


class Borrow(Base):
    __tablename__ = "borrowed_books"

    id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    user_id = Column(
        Integer,
        ForeignKey("users.id")
    )

    book_id = Column(
        Integer,
        ForeignKey("books.id")
    )

    borrow_date = Column(
        DateTime,
        default=datetime.utcnow
    )

    due_date = Column(
        DateTime,
        default=lambda: datetime.utcnow() + timedelta(days=7)
    )

    returned = Column(
        Boolean,
        default=False
    )