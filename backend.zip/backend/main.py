from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from database import engine, Base

from models import (
    user_model,
    book_model,
    borrow_model,
    reservation_model
)

from routes import (
    auth_routes,
    book_routes,
    borrow_routes,
    dashboard_routes,
    reservation_routes
)

app = FastAPI(
    title="Smart Library System",
    version="1.0.0"
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",

        "http://localhost:5174",
        "http://127.0.0.1:5174",

        "http://localhost:5175",
        "http://127.0.0.1:5175",

        "http://localhost:5176",
        "http://127.0.0.1:5176",

        "http://localhost:5177",
        "http://127.0.0.1:5177",

        "http://localhost:5178",
        "http://127.0.0.1:5178",

        "http://localhost:5179",
        "http://127.0.0.1:5179",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

Base.metadata.create_all(bind=engine)

app.include_router(auth_routes.router)
app.include_router(book_routes.router)
app.include_router(borrow_routes.router)
app.include_router(dashboard_routes.router)
app.include_router(reservation_routes.router)

@app.get("/")
def home():
    return {
        "message": "Smart Library API Running"
    }