from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from database import get_db
from models.book_model import Book
from models.borrow_model import Borrow
from schemas.book_schema import BookCreate, BookUpdate, BookResponse

router = APIRouter()


@router.post("/books")
def create_book(book: BookCreate, db: Session = Depends(get_db)):

    new_book = Book(
        title=book.title,
        author=book.author,
        genre=book.genre
    )

    db.add(new_book)
    db.commit()
    db.refresh(new_book)

    return {
        "message": "Book created successfully",
        "book": new_book
    }


@router.get("/books", response_model=list[BookResponse])
def get_books(db: Session = Depends(get_db)):
    return db.query(Book).all()


@router.get("/search")
def search_books(
    title: str = Query(None),
    author: str = Query(None),
    genre: str = Query(None),
    available: bool = Query(None),
    db: Session = Depends(get_db)
):
    books = db.query(Book)

    if title:
        books = books.filter(Book.title.ilike(f"%{title}%"))

    if author:
        books = books.filter(Book.author.ilike(f"%{author}%"))

    if genre:
        books = books.filter(Book.genre.ilike(f"%{genre}%"))

    if available is not None:
        books = books.filter(Book.available == available)

    results = books.all()

    return {
        "count": len(results),
        "books": results
    }


@router.delete("/books/{book_id}")
def delete_book(book_id: int, db: Session = Depends(get_db)):

    book = db.query(Book).filter(Book.id == book_id).first()

    if not book:
        raise HTTPException(
            status_code=404,
            detail="Book not found"
        )

    active_borrow = (
        db.query(Borrow)
        .filter(
            Borrow.book_id == book_id,
            Borrow.returned == False
        )
        .first()
    )

    if active_borrow:
        raise HTTPException(
            status_code=400,
            detail="Cannot delete a borrowed book"
        )

    db.delete(book)
    db.commit()

    return {
        "message": "Book deleted successfully"
    }


@router.put("/books/{book_id}")
def update_book(
    book_id: int,
    book: BookCreate,
    db: Session = Depends(get_db)
):
    existing_book = db.query(Book).filter(Book.id == book_id).first()

    if not existing_book:
        raise HTTPException(
            status_code=404,
            detail="Book not found"
        )

    existing_book.title = book.title
    existing_book.author = book.author
    existing_book.genre = book.genre

    db.commit()
    db.refresh(existing_book)

    return {
        "message": "Book updated successfully",
        "book": existing_book
    }


@router.patch("/books/{book_id}")
def patch_book(
    book_id: int,
    book: BookUpdate,
    db: Session = Depends(get_db)
):
    existing_book = db.query(Book).filter(Book.id == book_id).first()

    if not existing_book:
        raise HTTPException(
            status_code=404,
            detail="Book not found"
        )

    update_data = book.model_dump(exclude_unset=True)

    for key, value in update_data.items():
        setattr(existing_book, key, value)

    db.commit()
    db.refresh(existing_book)

    return {
        "message": "Book updated partially",
        "book": existing_book
    }