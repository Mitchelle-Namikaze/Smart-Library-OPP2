from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from datetime import datetime

from database import get_db
from models.book_model import Book
from models.borrow_model import Borrow
from models.user_model import User

router = APIRouter()


@router.get("/dashboard")
def dashboard_stats(db: Session = Depends(get_db)):

    total_books = db.query(Book).count()

    borrowed_books = (
        db.query(Borrow)
        .filter(Borrow.returned == False)
        .count()
    )

    available_books = (
        db.query(Book)
        .filter(Book.available == True)
        .count()
    )

    overdue_books = 0

    borrowed = (
        db.query(Borrow)
        .filter(Borrow.returned == False)
        .all()
    )

    for record in borrowed:
        if datetime.utcnow() > record.due_date:
            overdue_books += 1

    total_users = db.query(User).count()

    return {
        "total_books": total_books,
        "borrowed_books": borrowed_books,
        "available_books": available_books,
        "overdue_books": overdue_books,
        "total_users": total_users
    }