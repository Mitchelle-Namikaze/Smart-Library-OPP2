from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from datetime import datetime, timedelta

from database import get_db
from models.reservation_model import Reservation
from models.book_model import Book
from models.borrow_model import Borrow
from schemas.reservation_schema import (
    ReservationCreate,
    ReservationResponse
)

router = APIRouter()


@router.post("/reservations")
def create_reservation(
    reservation: ReservationCreate,
    db: Session = Depends(get_db)
):
    book = (
        db.query(Book)
        .filter(Book.id == reservation.book_id)
        .first()
    )

    if not book:
        raise HTTPException(
            status_code=404,
            detail="Book not found"
        )

    new_reservation = Reservation(
        user_id=reservation.user_id,
        book_id=reservation.book_id
    )

    db.add(new_reservation)
    db.commit()
    db.refresh(new_reservation)

    return {
        "message": "Reservation created successfully",
        "reservation": new_reservation
    }


@router.get(
    "/reservations",
    response_model=list[ReservationResponse]
)
def get_reservations(
    db: Session = Depends(get_db)
):
    return db.query(Reservation).all()


@router.put("/reservations/{reservation_id}/approve")
def approve_reservation(
    reservation_id: int,
    db: Session = Depends(get_db)
):
    reservation = (
        db.query(Reservation)
        .filter(Reservation.id == reservation_id)
        .first()
    )

    if not reservation:
        raise HTTPException(
            status_code=404,
            detail="Reservation not found"
        )

    if reservation.status != "Pending":
        raise HTTPException(
            status_code=400,
            detail="Reservation already processed"
        )

    book = (
        db.query(Book)
        .filter(Book.id == reservation.book_id)
        .first()
    )

    if not book:
        raise HTTPException(
            status_code=404,
            detail="Book not found"
        )

    if not book.available:
        raise HTTPException(
            status_code=400,
            detail="Book already borrowed"
        )

    borrow_record = Borrow(
        user_id=reservation.user_id,
        book_id=reservation.book_id,
        borrow_date=datetime.utcnow(),
        due_date=datetime.utcnow() + timedelta(days=7),
        returned=False
    )

    book.available = False
    reservation.status = "Approved"

    db.add(borrow_record)
    db.commit()
    db.refresh(borrow_record)

    return {
        "message": "Reservation approved and book borrowed",
        "borrow": {
            "borrow_id": borrow_record.id,
            "user_id": borrow_record.user_id,
            "book_id": borrow_record.book_id,
            "due_date": borrow_record.due_date
        }
    }


@router.put("/reservations/{reservation_id}/reject")
def reject_reservation(
    reservation_id: int,
    db: Session = Depends(get_db)
):
    reservation = (
        db.query(Reservation)
        .filter(Reservation.id == reservation_id)
        .first()
    )

    if not reservation:
        raise HTTPException(
            status_code=404,
            detail="Reservation not found"
        )

    if reservation.status != "Pending":
        raise HTTPException(
            status_code=400,
            detail="Reservation already processed"
        )

    reservation.status = "Rejected"

    db.commit()

    return {
        "message": "Reservation rejected"
    }