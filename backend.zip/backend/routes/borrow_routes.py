from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from datetime import datetime

from database import get_db
from models.book_model import Book
from models.borrow_model import Borrow
from schemas.borrow_schema import BorrowCreate, BorrowResponse

router = APIRouter()


@router.post("/borrow")
def borrow_book(borrow: BorrowCreate, db: Session = Depends(get_db)):

    book = db.query(Book).filter(Book.id == borrow.book_id).first()

    if not book:
        raise HTTPException(
            status_code=404,
            detail="Book not found"
        )

    if not book.available:
        raise HTTPException(
            status_code=400,
            detail="Book already borrowed"
        )

    book.available = False

    borrow_record = Borrow(
        user_id=borrow.user_id,
        book_id=borrow.book_id
    )

    db.add(borrow_record)
    db.commit()
    db.refresh(borrow_record)

    return {
        "message": "Book borrowed successfully",
        "borrow": {
            "borrow_id": borrow_record.id,
            "book_id": borrow_record.book_id,
            "user_id": borrow_record.user_id,
            "due_date": borrow_record.due_date
        }
    }


@router.post("/return")
def return_book(book_id: int, db: Session = Depends(get_db)):

    book = db.query(Book).filter(Book.id == book_id).first()

    if not book:
        raise HTTPException(
            status_code=404,
            detail="Book not found"
        )

    borrow_record = (
        db.query(Borrow)
        .filter(
            Borrow.book_id == book_id,
            Borrow.returned == False
        )
        .first()
    )

    if not borrow_record:
        raise HTTPException(
            status_code=404,
            detail="Borrow record not found"
        )

    book.available = True
    borrow_record.returned = True

    db.commit()

    return {
        "message": "Book returned successfully"
    }


@router.get("/overdue")
def overdue_books(db: Session = Depends(get_db)):

    borrowed_books = (
        db.query(Borrow)
        .filter(Borrow.returned == False)
        .all()
    )

    overdue_list = []

    for record in borrowed_books:
        if datetime.utcnow() > record.due_date:
            overdue_days = (datetime.utcnow() - record.due_date).days

            overdue_list.append({
                "borrow_id": record.id,
                "user_id": record.user_id,
                "book_id": record.book_id,
                "due_date": record.due_date,
                "overdue_days": overdue_days
            })

    return {
        "count": len(overdue_list),
        "overdue_books": overdue_list
    }


@router.get("/borrowed", response_model=list[BorrowResponse])
def get_borrowed_books(db: Session = Depends(get_db)):
    return (
        db.query(Borrow)
        .filter(Borrow.returned == False)
        .all()
    )